#! /usr/bin/env ruby

def ack(i, j)
	if(i == 0)
		return j+1			
	elsif(i > j and j == 0)
		return ack(i-1, 1)
	else			    
		return ack(i-1, ack(i, j-1))	
	end
end

if ARGV.length != 2
	puts "ack.rb usage: [NUMBER]"
	exit
end

puts ack(ARGV[0].to_i, ARGV[1].to_i)
