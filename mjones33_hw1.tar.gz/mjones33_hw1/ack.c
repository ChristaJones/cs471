#include <stdio.h>
#include <stdlib.h>


int ack(int i, int j)
{ 
	if(i == 0)
		return j+1;			
	if(i > j && j == 0)
		return ack(i-1, 1);
	else			    
		return ack(i-1, ack(i, j-1));		
}

int main(int argc, char **argv) {
  if (argc < 3) {
    printf("%s usage: [M] [N]\n", argv[0]);
    return 1;
  }
  int i = atoi(argv[1]);
  int j = atoi(argv[2]);
  int r = ack(i,j);
  printf("%d\n", r);
  return 0;
}
