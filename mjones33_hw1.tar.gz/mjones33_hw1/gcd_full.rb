#! /usr/bin/env ruby
def gcdI(i, j)
	while i != j 
		if i > j 
			i = i - j
		else
			j = j - i 
		end
	end
	return i
end

def gcdM(i, j)
	while i != j
		if i == 0
			return j
		elsif j == 0
			return i
		elsif i > j 
			i = i.modulo(j)
		else
			j = j.modulo(i)
		end
	end
   return i;
end

def gcdF(i, j) 
	if(j == 0 or i == j)
		return i			
	elsif(i == 0)
		return j
	else			    
		if i > j
			return gcdF(i-j, j)
		else			
			return gcdF(i, j-i)	
		end
	end
end

if ARGV.length != 2
	puts "gcd_full.rb usage: [NUMBER]"
	exit
end

puts gcdF(ARGV[0].to_i, ARGV[1].to_i)
