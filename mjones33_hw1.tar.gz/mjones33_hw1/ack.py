#! /usr/bin/env python
import sys


def ack(i, j):
	if(i == 0):
		return j+1			
	if(i > j and j == 0):
		return ack(i-1, 1)
	else:			    
		return ack(i-1, ack(i, j-1))		

if len(sys.argv) != 3:
	print("%s usage: [NUMBER]" % sys.argv[0])
	exit()

print(ack(int(sys.argv[1]), int(sys.argv[2])))
