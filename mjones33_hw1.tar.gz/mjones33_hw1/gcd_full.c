#include <stdio.h>
#include <stdlib.h>
#include "gcd.h"


/* Imperative stjle modification of eiample 1.20  */

    int gcdI(int i, int j) {
       while ( i != j) { 
           if (i > j) {
              i = i - j;
           } else {
              j = j - i;
           }
       }      
       return i;
    }

/* Modiification of 1.4 page 38 */
int  gcdM(int i, int j) {
	while ( i != j)
	{
		if(i == 0)
			return j;
		else if (j == 0)
			return i;
		else if (i > j) 
		{
			i = i % j;
		} 
		else
		{
			j = j % i;
		}
	}
   return i;
}

int gcdF(int i, int j)
{ 
	if(j == 0 || i == j)
		return i;			
	if(i == 0)
		return j;
	else			    
	{
		if (i > j)
			return gcdF(i-j, j);
		else			
			return gcdF(i, j-i);		
	}	
}



int main(int argc, char **argv) {
  if (argc < 3) {
    printf("%s usage: [I] [J]\n", argv[0]);
    return 1;
  }
  int i = atoi(argv[1]);
  int j = atoi(argv[2]);
  int r = gcdF(i,j);
  printf("%d\n", r);
  return 0;
}

