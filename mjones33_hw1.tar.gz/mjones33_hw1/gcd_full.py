#! /usr/bin/env python
import sys
def gcdI(i, j):
	while i != j: 
		if i > j: 
			i = i - j
		else:
			j = j - i 
	return i

def gcdM(i, j):
	while i != j:
		if i == 0:
			return j
		elif j == 0:
			return i
		elif i > j: 
			i = i % j
		else:
			j = j % i
   return i;

def gcdF(i, j): 
	if(j == 0 or i == j):
		return i			
	if(i == 0):
		return j
	else:			    
		if i > j:
			return gcdF(i-j, j)
		else:			
			return gcdF(i, j-i)		

if len(sys.argv) != 3:
	print("%s usage: [NUMBER]" % sys.argv[0])
	exit()

print(gcdF(int(sys.argv[1]), int(sys.argv[2])))

